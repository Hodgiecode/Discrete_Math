class Task_02_01:
    def main(self,data):
        data=data.split(" ")
        
        k=data[0]
        k=int(k)
        n=data[1]
        n=int(n)

        vect = []
        flag = 1
        
        for i in range(k**n): vect.append(data[2][i])

        for i in range(k**n):
            for j in range(i+1, k**n): #второй цикл будет искать соседний и сравнивать
                if ((i&j) == i and int(vect[i]) > int(vect[j])):
                    # i является подмаской j и нарушается монотонность
                    # При помощи конъюнуции определяем какие можно сравнивать а какие нет и дальше смотрим на значение наборов
                    flag = 0
                    break

        if flag == 0:
            rtn = 0
        else:
            rtn = 1

        return rtn
