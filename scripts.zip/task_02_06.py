class Task_02_06:
    def __init__(self):
        self.set_of_vectorvalue=[]
        self.table=[]

    def sort(self,m,left,right):
        mid=m[int((right+left)/2)]
        i=left
        j=right
        while not i>j:
            while m[i]<mid: i=i+1
            while m[j]>mid: j=j-1
            if not i>j:
                m[i],m[j]=m[j],m[i]
                i=i+1
                j=j-1

        if i<right: self.sort(m,i,right)
        if left<j: self.sort(m,left,j)

        return m
        
    def main(self,data):
        data=data.split(" ")
        k=int(data[0])
        n=int(data[1])
        vec=[int(data[2][i]) for i in range(len(data[2]))]

        z=10*k
        arr=[]
        mas=[]
        viv=[0 for j in range(k)]
        funcn=0
        
        for i in range(z):
            tmp=[0 for j in range(k)]
            mas.append(tmp)
            arr.append(0)

        af=0
        for i in range(k):
            mas[funcn][i]=vec[i*(k+1)]
            af=af*k+mas[funcn][i]
            '''
            poluchayu perviy vektor funkcii superpoziciey vida f1=f(x,x)
            gde f-zadannaya funkciya
            '''
        arr[funcn]=af
        funcn=funcn+1
        
        while funcn<z:
            an=0
            for i in range(k):
                #poluchayu vektor vida f(fi(x),x)
                mas[funcn][i]=vec[mas[funcn-1][i]+k*i]
                an=an*k+mas[funcn][i]

            arr[funcn]=an
            if an==af:
                for i in range(k):
                    mas[funcn][i]=0
                    arr[funcn]=0

                break

            funcn=funcn+1

        ded=0
        i=0
        while True:
            j=0
            if i>funcn-1:
                break
            
            while True:
                if j>funcn-1:
                    break
                
                an=0
                er=0
                for s in range(k):
                    #poluchayu vektor vida f(fi(x),fj(x));
                    mas[funcn][s]=vec[mas[i][s]*k+mas[j][s]]
                    an=an*k+mas[funcn][s]
                   
                for s in range(funcn):
                    if an==arr[s]:
                        arr[funcn]=0
                        for n in range(k):
                            mas[funcn][n]=0

                        er=1
                        break

                    s=s+1

                if er!=1:
                    arr[funcn]=an
                   
                    if funcn==z:
                        ded=1
                        break

                    funcn=funcn+1

                j=j+1
                
            i=i+1
            if ded==1:
                break
            
        
        arr=self.sort(arr,0,funcn-1)
        s=""
        for i in range(funcn):
            an=arr[i]
            s=s+str(k)+" 1 "
            for j in range(k):
                viv[k-1-j]=int(an%k)
                an=an/k
                
            for j in range(k): s=s+str(viv[j])
            s=s+"\n"

        
        return s

