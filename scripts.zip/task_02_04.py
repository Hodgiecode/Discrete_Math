class Task_02_04:
    def __init__(self):
        self.set_of_vectorvalue=[]
        self.table=[]

    def tablize(self,x,k_values,truths=[]):
        if not x:
            self.table.append(truths)
        else:
            for i in k_values:
                self.tablize(x-1,k_values,truths+[i])


    def partition(self,collection): #строим разбиения
        if len(collection)==1:
            yield [collection]
            return

        first=collection[0]
        for smaller in self.partition(collection[1:]):
            for n,subset in enumerate(smaller):
                yield smaller[:n]+[[first]+subset]+smaller[n+1:]

            yield[[first]]+smaller

   
    def main(self,data):
        data=data.split(" ")
        k=int(data[0])
        n=int(data[1])
        vector_of_values=[int(data[2][i]) for i in range(len(data[2]))]

        k_values=[i for i in range(k)]
        self.tablize(n,k_values)

        general_partition=[p[1] for p in enumerate(self.partition(k_values))] #строим все возможные разбиения
        partition_nabor=[]
        res1=[]
        res2=[]
        
        for i in range(len(general_partition)):
            partition_nabor.append([])
            res1.append([])
        
        
        for index,partition in enumerate(general_partition):
               for i in range(len(self.table)):
                    for j in range(i+1,len(self.table)):
                        flag=1
                        for m1 in range(len(self.table[i])):
                            if self.table[i][m1]==self.table[j][m1]:
                                set_in=[self.table[i][m1]]
                            else:
                                set_in=[self.table[i][m1],self.table[j][m1]]

                            if not set_in in partition:
                                flag=0
                                break

                        if flag==1:
                            partition_nabor[index].append([self.table[i],self.table[j]])
                            res1[index]=partition

        for i in range(len(res1)):
            if res1[i]!=[]:
                temp=[]
                for j in range(len(partition_nabor[i])):
                    for m1 in range(len(partition_nabor[i][j])):
                        for m2 in range(len(self.table)):
                            if self.table[m2]==partition_nabor[i][j][m1]:
                                temp.append(vector_of_values[m2])
                                
                count=0
                for p in range(0,len(temp),2):
                    A=set([temp[p],temp[p+1]])
                    for x in range(len(res1[i])):
                        if A.issubset(set(res1[i][x]))==True:
                            count=count+1

                if count==len(partition_nabor[i]):
                    res2.append(res1[i])

        if n==1:
            res2=[res2[0]]
            
        #сортировка
        for i in range(len(res2)):
            for j in range(len(res2[i])):
                for k1 in range(len(res2[i])):
                    for k2 in range(k1+1,len(res2[i])):
                        if res2[i][k1]>res2[i][k2]:
                            res2[i][k1],res2[i][k2]=res2[i][k2],res2[i][k1]

        #вывод
        s=""
        for i in range(len(res2)):
            s2=""
            for j in range(len(res2[i])):
                s2=s2+" "
                for k in range(len(res2[i][j])):
                    s2=s2+str(res2[i][j][k])

            if i==0:
                s=s2+"\n"
            else:
                if i!=len(res2)-1:
                    s=s+s2+"\n"
                else:
                    s=s+s2
        
        return s

