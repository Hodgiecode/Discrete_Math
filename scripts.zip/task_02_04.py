class Task_02_04:
    def __init__(self):
        self.set_of_vectorvalue=[]
        self.table=[]

    def tablize(self,x,k_values,truths=[]):
        if not x:
            self.table.append(truths)
        else:
            for i in k_values:
                self.tablize(x-1,k_values,truths+[i])

    def powerset(self,s,k):#строим множество размера k
        x=len(s)
        ps=[]
        for i in range(1<<x):
            a=[s[j] for j in range(x) if (i & (1<<j))]
            if len(a)==k:
                ps.append(a)

        return ps

    def partition(self,collection): #строим разбиения
        if len(collection)==1:
            yield [collection]
            return

        first=collection[0]
        for smaller in self.partition(collection[1:]):
            for n,subset in enumerate(smaller):
                yield smaller[:n]+[[first]+subset]+smaller[n+1:]

            yield[[first]]+smaller

    def checker_one(self,vector_of_values,lst): #выбираем только те наборы, значение на котором лежим в множестве, полученном из данного набора
        for j in range(len(lst)):
            for k in range(len(self.table)):
                if self.table[k]==lst[j]:
                    if not int(vector_of_values[k]) in lst[j]:
                        return 0

        return 1

    def checker_two(self,vector_of_values,lst):
        for i in range(len(lst)):
            for m in range(len(lst[i])):
              a=self.powerset(lst[i],m+1) #проверяем, чтобы значение на каждом из наборов лежало в этом множестве и в этом множестве не лежало множество, которое уже содержит все значения
              for k in range(len(a)):
                  for k2 in range(len(self.table)):
                      if self.table[k2]==a[k]:
                          if not self.set_of_vectorvalue in lst and not int(vector_of_values[k2]) in lst[i]:
                              return 0
                      
        return 1

    def main(self,data):
        data=data.split(" ")
        k=int(data[0])
        n=int(data[1])
        vector_of_values=[int(data[2][i]) for i in range(len(data[2]))]

        self.set_of_vectorvalue=sorted(list(set([int(data[2][i]) for i in range(len(data[2]))]))) #генерируем множество значений вектора значенмй

        k_values=[i for i in range(k)]
        self.tablize(n,k_values)

        for i in range(len(self.table)):
            self.table[i]=sorted(list(set(self.table[i])))

        general_partition=[p[1] for p in enumerate(self.partition(k_values))] #строим все возможные разбиения
        res_etap_one=[]

        #проверяем, чтобы все множества в разбиении сохраняли соответсвующее значение на векторе значений
        for i in range(len(general_partition)):
            v=self.checker_one(vector_of_values,general_partition[i])
            if v==1:
                res_etap_one.append(general_partition[i])

        #для полученных на предыдущем этапе множеств генерируем все их подмножества (размера 1,..,k-1) и смотрим, что и там значение сохраняется
        res_etap_two=[]
        for i in range(len(res_etap_one)):
            if self.checker_two(vector_of_values,res_etap_one[i])==1:
                if len(res_etap_one[i])!=1 and res_etap_one[i][0]!=k_values: #костыль - отсекаем множество состоящее из всех значений от 0 до k-1
                    flag=1
                    for p in range(len(res_etap_one[i])): #выкидываем множества, целиком состоящее только из одноэлементных подмножеств
                        if len(res_etap_one[i][p])!=1:
                            flag=0
                            break

                    if flag==0:
                        res_etap_two.append(res_etap_one[i])
                
        #сортировка
        for i in range(len(res_etap_two)):
            for j in range(len(res_etap_two[i])):
                for k1 in range(len(res_etap_two[i])):
                    for k2 in range(k1+1,len(res_etap_two[i])):
                        if res_etap_two[i][k1]>res_etap_two[i][k2]:
                            res_etap_two[i][k1],res_etap_two[i][k2]=res_etap_two[i][k2],res_etap_two[i][k1]

        #вывод
        s=""
        for i in range(len(res_etap_two)):
            s2=""
            for j in range(len(res_etap_two[i])):
                s2=s2+" "
                for k in range(len(res_etap_two[i][j])):
                    s2=s2+str(res_etap_two[i][j][k])

            if i==0:
                s=s2+"\n"
            else:
                if i!=len(res_etap_two)-1:
                    s=s+s2+"\n"
                else:
                    s=s+s2

        return s
        

