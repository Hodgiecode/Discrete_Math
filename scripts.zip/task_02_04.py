class Task_02_04:
    def __init__(self):
        self.set_of_vectorvalue=[]
        self.table=[]

    def tablize(self,x,k_values,truths=[]):
        if not x:
            self.table.append(truths)
        else:
            for i in k_values:
                self.tablize(x-1,k_values,truths+[i])


    def partition(self,collection): #строим разбиения
        if len(collection)==1:
            yield [collection]
            return

        first=collection[0]
        for smaller in self.partition(collection[1:]):
            for n,subset in enumerate(smaller):
                yield smaller[:n]+[[first]+subset]+smaller[n+1:]

            yield[[first]]+smaller


    def powerset(self,s,k):#строим множество размера k
        x=len(s)
        ps=[]
        for i in range(1<<x):
            a=[s[j] for j in range(x) if (i & (1<<j))]
            if len(a)==k:
                ps.append(a)

        return ps


    def checker_function(self,vector_of_values,partition):
        for i in range(len(partition)):
            for m in range(len(partition[i])):
              a=self.powerset(partition[i],m+1)
              for k1 in range(len(a)):
                  for k2 in range(len(self.table)):
                      if sorted(list(set(self.table[k2])))==a[k1]:
                          if not int(vector_of_values[k2]) in partition[i]:
                              return 0
                      
        return 1


    def main(self,data):
        data=data.split(" ")
        k=int(data[0])
        n=int(data[1])
        vector_of_values=[int(data[2][i]) for i in range(len(data[2]))]

        k_values=[i for i in range(k)]
        self.tablize(n,k_values)

        general_partition=[p[1] for p in enumerate(self.partition(k_values))] #строим все возможные разбиения
        res_etap_one=[]
        res_etap_two=[]

        for partition in general_partition:
            for i in range(len(self.table)):
                for j in range(i+1,len(self.table)):
                    flag=1
                    for m1 in range(len(self.table[i])):
                        set_in=[self.table[i][m1],self.table[j][m1]]
                        if not set_in in partition:
                            flag=0
                            break

                    if flag==1:
                        res_etap_one.append(partition)

        for partition in res_etap_one:
            if self.checker_function(vector_of_values,partition)==1:
                res_etap_two.append(partition)
                    
        #сортировка
        for i in range(len(res_etap_two)):
            for j in range(len(res_etap_two[i])):
                for k1 in range(len(res_etap_two[i])):
                    for k2 in range(k1+1,len(res_etap_two[i])):
                        if res_etap_two[i][k1]>res_etap_two[i][k2]:
                            res_etap_two[i][k1],res_etap_two[i][k2]=res_etap_two[i][k2],res_etap_two[i][k1]

        #вывод
        s=""
        for i in range(len(res_etap_two)):
            s2=""
            for j in range(len(res_etap_two[i])):
                s2=s2+" "
                for k in range(len(res_etap_two[i][j])):
                    s2=s2+str(res_etap_two[i][j][k])

            if i==0:
                s=s2+"\n"
            else:
                if i!=len(res_etap_two)-1:
                    s=s+s2+"\n"
                else:
                    s=s+s2
    
        return s


