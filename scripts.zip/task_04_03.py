class Task_04_03:
    def main(self,data):
        data=data.split('\n')
        n,m=data[0].split(" ")
        n=int(n)
        m=int(m)
        vec=data[1:]

        res_k=n
        res_n=0
        res=[]
        
        for i in range(len(vec)):
            for j in range(i+1,len(vec)):
                if len(vec[i]) == 0 or len(vec[j])==0:
                        continue
                
                diff = 0
                c1 = 0
                c2 = 0
                pos=[]
                
                for k in range(n):    
                    if vec[i][k] == vec[j][k]:
                        continue
                        
                    if vec[i][k] != vec[j][k]:
                        diff = diff+1
                        pos.append(k)

            
                if diff == 0:
                    vec[j]=""
                else:
                    if diff != n:
                        p=0
                        is_absorbable=1

                        while pos != []:
                            p = pos[-1]
                            pos = pos[:-1]
                       
                            if vec[i][p] == "*":
                                c1 = c1+1
                            else:
                                if vec[j][p] == "*":
                                    c2 = c2+1

                                if vec[i][p]!="*" and vec[j][p]!="*":
                                        is_absorbable=0
                                        break

                        if is_absorbable == 1:
                            if c1>c2:
                                vec[j]=""
                            else:
                                if c1<c2:
                                    vec[i]=""
                  
        for i in range(len(vec)):
            if vec[i]!="":
                res.append(vec[i])

        res_n=len(res)

        s=str(res_k)+" "+str(res_n)+"\n"
        for i in range(len(res)):
            s=s+res[i]+"\n"

        s=s.strip()
        return s
